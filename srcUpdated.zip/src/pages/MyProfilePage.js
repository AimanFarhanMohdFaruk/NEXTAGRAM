import React from 'react'
import {useState, useEffect} from 'react'
import axios from 'axios'


const MyProfilePage = () => {

    const [user, setUser] = useState({})

    useEffect(() => {
        axios.get("https://insta.nextacademy.com/api/v1/users/me",
        {
            headers: {
                "Authorization": "Bearer " + localStorage.getItem("jwt")
            }
        })
        .then(result => {
            console.log(result)
            setUser(result.data)
        })
        .catch(error => {
            console.log(error)
        })
    },[])
    


    return(
        <div>MyProfile</div>
    )

}

export default MyProfilePage;