import React from 'react'
import loadgif from "../Dual Ball-1s-200px.gif"


const Loader = () => {
        return(
        <div> 
                <img src={loadgif}/>  
        </div>
        ) 

}

export default Loader;